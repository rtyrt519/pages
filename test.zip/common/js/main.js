// スライドショー

let nowPage = 0; //表示する画像
let nextPage = 1; //次に表示する画像
const slides = $('#slideshow img');
const slideLength = slides.length; // 4
const fadeTime = 2000; //2秒かけて次の画像へ
const showTime = 4500; //4.5秒間画面に映る

const slideshow = () => {
 nextPage = (nowPage + 1) % slideLength;
 slides.eq(nowPage).fadeOut(fadeTime);
 slides.eq(nextPage).fadeIn(fadeTime);
 nowPage = nextPage;
}


slides.hide();
slides.eq(0).show();
setInterval(slideshow ,showTime);

//TEL
var ua = navigator.userAgent.toLowerCase();
var isMobile = /iphone/.test(ua)||/android(.+)?mobile/.test(ua);

if (!isMobile) {
    $('a[href^="tel:"]').on('click', function(e) {
        e.preventDefault();
    });
}


//TOPへ戻るボタンが途中からふわっと出てくる
jQuery(function() {
    var pagetop = $('.page_top');
    pagetop.hide();
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {  //300pxスクロールしたら表示
            pagetop.fadeIn();
        } else {
            pagetop.fadeOut();
        }
    });
    pagetop.click(function () {
        $('body,html').animate({
            scrollTop: 0
        }, 500); //0.5秒かけてトップへ移動
        return false;
    });
});

// #で始まるリンクをクリックしたら実行されます
$('a[href^="#"]').click(function() {
  // スクロールの速度
  var speed = 400; // ミリ秒で記述
  var href= $(this).attr("href");
  var target = $(href == "#" || href == "" ? 'html' : href);
  var position = target.offset().top;
  $('body,html').animate({scrollTop:position}, speed, 'swing');
  return false;
});


//チェックボタンクリックしないとリンク先に飛べません
$(".ECM_CheckboxInput").change(function () {
    $(".confirm-agree-btn").toggleClass("active");
  });


$('.humburger-menu').click(function(){
$(this).toggleClass('sp-menu-active');
$('.nav-sp').toggleClass('sp-menu-active');
});


$('.time-bord-1').click(function(){
    $(this).find('.plus-btn').toggleClass('active');
    $('.time-bord-1-first-wrapper').slideToggle('active');
    });

    $('.time-bord-2').click(function(){
        $(this).find('.plus-btn').toggleClass('active');
        $('.time-bord-2-second').slideToggle('active');
        });
    



        $('.nav-sp-ul-li').click(function(){
            $(this).find('.sp-nav-submenu').slideToggle('active');
            $(this).find('.plus-btn').toggleClass('active');
            });